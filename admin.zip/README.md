# Notifcaster
Notifcaster is a free service for sending notifications directly to Telegram.
The plugin allows user to receive WordPress notifications in their Telegram account and publish their posts to Telegram channel.

###Connect Notifcaster to WordPress site
1. Install Telegram for WordPress plugin and activate it on your WordPress site
2. Go to TWP Settings Page in Wordpress dashboard.
3. Follow the guides in the page.

There is also an online document in <a href="http://notifcaster.com"> Notifcaster </a>

###Feedback
Call me on Telegram: @ameer_mousavi
